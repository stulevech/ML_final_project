################### ML Project: Data setup ##########################

### This takes Joe's code and creates a dataset for pixels. I've added some code to consolidate PC-loadings

### Installing EBImage from BioConductor:
if (!requireNamespace("BiocManager", quietly = TRUE)){
  install.packages("BiocManager")}
BiocManager::install("EBImage", version = "3.8")

### Required packages
library(tidyverse)
library(EBImage)
library(jpeg)
library(reshape2)

################### Extracting images for gondola, sailboat, and cruiseship (Image --> resize --> pixels) #############

gondola.filenames <- list.files(path = "gondola", pattern="*.jpg")
sailboat.filenames <- list.files(path = "sailboat", pattern="*.jpg")
cruiseship.filenames <- list.files(path = "cruise ship", pattern="*.jpg")

gondola.filenames <- sample(gondola.filenames, 200)
sailboat.filenames <- sample(sailboat.filenames, 200)
cruiseship.filenames = cruiseship.filenames[-26] # removing the one PNG image 
cruiseship.filenames <- sample(cruiseship.filenames, 200) 

setwd("/Users/sumati/Documents/STOR 565/Project/boats/gondola")

gondola.array <-
  array(NA, dim = c(115, 345, length(gondola.filenames)))

for (i in 1:length(gondola.filenames)){
  im <- readJPEG(gondola.filenames[i])
  im <- EBImage::resize(im, w = 115, h = 345) # resize image 
  im <- im[,,3] # isolate pixel intensities, blue instead of red 
  gondola.array[,,i] <- im
}

setwd("/Users/sumati/Documents/STOR 565/Project/boats/sailboat")

sailboat.array <-
  array(NA, dim = c(115, 345, length(sailboat.filenames)))

for (i in 1:length(sailboat.filenames)){
  im <- readJPEG(sailboat.filenames[i])
  im <- EBImage::resize(im, w = 115, h = 345) # resize image 
  im <- im[,,3] # isolate pixel intensities 
  sailboat.array[,,i] <- im
}

setwd("/Users/sumati/Documents/STOR 565/Project/boats/cruise ship")


cruiseship.array <-
  array(NA, dim = c(115, 345, length(cruiseship.filenames)))

for (i in 1:length(cruiseship.filenames)){
  im <- readJPEG(cruiseship.filenames[i])
  im <- EBImage::resize(im, w = 115, h = 345) # resize image 
  im <- im[,,3] # isolate pixel intensities 
  cruiseship.array[,,i] <- im
}


setwd("/Users/sumati/Documents/STOR 565/Project/boats")

boats <- matrix(NA, nrow = 600, ncol = 1+(115*345))
boats[,1] <- rep(c(1,2,3), each = 200)
# 1, 2, 3 is gondola, sailboat, cruise

for (i in 1:200){
  melt.array <- melt(gondola.array[,,i])[,3]
  
  for (j in 2:ncol(boats)){
    boats[i,j] <- melt.array[j-1]
  }
}

for (i in 201:400){
  melt.array <- melt(sailboat.array[,,i-200])[,3]
  
  for (j in 2:ncol(boats)){
    boats[i,j] <- melt.array[j-1]
  }
}

for (i in 401:600){
  melt.array <- melt(cruiseship.array[,,i-400])[,3]
  
  for (j in 2:ncol(boats)){
    boats[i,j] <- melt.array[j-1]
  }
}

boats <- as.data.frame(boats)

colnames(boats)[1] <- c("type")

boats$type <- ifelse(boats$type == 1, "gondola", 
                     ifelse(boats$type == 2, "sailboat", "cruise"))

# write_csv(boats, 'boats_pixels_blue.csv')

gondola = boats %>% filter(type == 'gondola')
write_csv(gondola, 'gondola_200_blue.csv')
sailboat = boats %>% filter(type == 'sailboat')
write_csv(sailboat, 'sailboat_200_blue.csv')
cruise = boats %>% filter(type == 'cruise')
write_csv(cruise, 'cruise_200_blue.csv')

### Exploratory: how many PCs would be needed? 
# The number of principal components, for each boat image, 
  # that explain 90 percent of the variation in the image’s pixel intensities
components.vec <- numeric(nrow(boats))
for (i in 1:nrow(boats)){
  row <- boats[i, 2:ncol(boats)] %>% as.numeric()
  row.mat <- matrix(row, 
                    nrow = 115, ncol = 345)
  pr.out <- prcomp(row.mat)
  pr.var <- pr.out$sdev^2
  pve <- pr.var / sum(pr.var)
  components.vec[i] <- min(which(cumsum(pve) > 0.9))
}

plot(density(components.vec))
mean(components.vec)
median(components.vec)

# keep 40 components


########################### Keras Implementation: Basic NN #############

library(devtools)
devtools::install_github("rstudio/keras")
library(keras)
library(tensorflow)
# install_keras()
install_tensorflow()

### Data Setup
setwd("~/Documents/STOR 565/Project/boats")
# list images in path 
gondola.filenames <- list.files(path = "gondola", pattern="*.jpg")
sailboat.filenames <- list.files(path = "sailboat", pattern="*.jpg")
cruiseship.filenames <- list.files(path = "cruise ship", pattern="*.jpg")

gondola.filenames <- gondola.filenames[1:100]
sailboat.filenames <- sailboat.filenames[1:100]
cruiseship.filenames <- cruiseship.filenames[c(1:25, 27:101)] # removing the one PNG image 

# function to process images: resize, turn greyscale, turn to vector 
# (Basically Joe's code plus tutorial code in one function)
process_images = function(directory, filenames){
  setwd(directory)
  boat.images = matrix(NA, ncol = 2500)
  for (i in 1:length(filenames)) {
    # read image 
    img = readImage(filenames[i])
    # resize image 
    img_resized = resize(img, w = width, h = height)
    # set grayscale 
    grayimg = channel(img_resized, 'gray')
    # image as matrix 
    img_matrix = grayimg@.Data
    # coerce to a vector (row-wise)
    img_vector = as.vector(t(img_matrix))
    boat.images = rbind(boat.images, img_vector)
    
  }
  boat.images = boat.images[-1, ]
  return(boat.images)
}

width = 50
height = 50
img_size = width*height
gondola.images = process_images('/Users/sumati/Documents/STOR 565/Project/boats/gondola', gondola.filenames)
sailboat.images = process_images('/Users/sumati/Documents/STOR 565/Project/boats/sailboat/', sailboat.filenames)
cruise.images = process_images('/Users/sumati/Documents/STOR 565/Project/boats/cruise ship/', cruiseship.filenames)

images = rbind(gondola.images, sailboat.images, cruise.images)
# 1: gondola, 2: sailboat, 3: cruiseship 
boat_type = c(rep(1, 100), rep(2, 100), rep(3, 100))
images = cbind(boat_type, images)


### NN: model setup and training
set.seed(2)
train_id = sample(nrow(images), floor(0.8*(nrow(images))))
TRAIN = images[train_id, ]
train_pixels = TRAIN[, -1]
train_labs = TRAIN[, 1]
train_labs = train_labs - 1
train_labs = to_categorical(train_labs, 3)
TEST = images[-train_id, ]
test_pixels = TEST[, -1] 
test_labs = TEST[, 1]
test_labs = test_labs - 1
test_labs = to_categorical(test_labs, 3)


# NN: model setup and training

model = keras_model_sequential()

model %>% layer_dense(units = 56, activation = 'relu', 
                      input_shape = c(dim(train_pixels)[2])) %>%
  layer_dropout(rate = 0.25) %>% 
  layer_dense(units = 28, activation = 'relu') %>%
  layer_dropout(rate = 0.25) %>% 
  layer_dense(units = 3, activation = 'softmax')


summary(model)

model %>% compile(
  loss = 'categorical_crossentropy',
  optimizer = optimizer_rmsprop(),
  metrics = c('accuracy')
)

history <- model %>% fit(
  train_pixels, train_labs, 
  epochs = 30, batch_size = 128, 
  validation_split = 0.2
)


# model test 
model %>% evaluate(test_pixels, test_labs)

#################### CNN #########################

model = keras_model_sequential()
model %>% 
  layer_conv_2d(filter=32,kernel_size=c(3,3),padding="same", input_shape = c(dim(train_pixels))) %>%  
  layer_activation("relu") %>% 
  layer_conv_2d(filter=32 ,kernel_size=c(3,3))  %>%  layer_activation("relu") %>%
  layer_max_pooling_2d(pool_size=c(2,2)) %>%
  layer_dropout(0.25) %>%
  layer_conv_2d(filter=32 , kernel_size=c(3,3),padding="same") %>% layer_activation("relu") %>%  layer_conv_2d(filter=32,kernel_size=c(3,3) ) %>%  layer_activation("relu") %>%  
  layer_max_pooling_2d(pool_size=c(2,2)) %>%  
  layer_dropout(0.25) %>%
  #flatten the input  
  layer_flatten() %>%  
  layer_dense(512) %>%  
  layer_activation("relu") %>%  
  layer_dropout(0.5) %>%  
  #output layer
  layer_dense(3) %>% 
  layer_activation("softmax") 

opt <- optimizer_adam(lr= 0.0001 , decay = 1e-6 )

model %>%
  compile(loss="categorical_crossentropy",
          optimizer=opt,metrics = "accuracy")

summary(model)

history <- model %>% fit(
  train_pixels, train_labs, 
  epochs = 30, batch_size = 128, 
  validation_split = 0.2
)

