######## imagR ##########
library(imager)
library(tidyverse)

### This script is for creating pixels from edge detection, and then using those pixels for decision trees
# also has code for applying the pixels from Otsu's method on here. 


#### DATA SETUP: EXTRACTING EDGES AND FORMING NEW PIXEL DATASET OF EDGES (GRAYSCALE) ########
gondola.filenames <- list.files(path = "gondola", pattern="*.jpg")
sailboat.filenames <- list.files(path = "sailboat", pattern="*.jpg")
cruiseship.filenames <- list.files(path = "cruise ship", pattern="*.jpg")

gondola.filenames <- sample(gondola.filenames, 200)
sailboat.filenames <- sample(sailboat.filenames, 200)
cruiseship.filenames = cruiseship.filenames[-26] # removing the one PNG image 
cruiseship.filenames <- sample(cruiseship.filenames, 200) 

path = paste0('/Users/sumati/Documents/STOR 565/Project/boats/', 'sailboat/', 
              sailboat.filenames[[2]])

boat <- load.image(path)
plot(boat)


## Edge Detection ## 
# source: https://cran.r-project.org/web/packages/imager/vignettes/gettingstarted.html#example-2-edge-detection

gr <- imgradient(boat,"xy")
gr

plot(gr,layout="row")

boat <- grayscale(boat)
dx <- imgradient(boat,"x")
dy <- imgradient(boat,"y")
grad.mag <- sqrt(dx^2+dy^2)
plot(grad.mag,main="Gradient magnitude")


# function to extract gradient magnitudes from each image, and compile into one array 
get_edge_pic_array = function(boat_path, filenames){
 boat.array <-
    array(NA, dim = c(115, 345, length(filenames)))
 
  for (i in 1:length(filenames)) {
    path = paste0('/Users/sumati/Documents/STOR 565/Project/boats/', 
                  boat_path, filenames[[i]]) 
    boat <- load.image(path) # load image 
    boat = imager::resize(boat, 115, 345, 1, 1) # resize image 
    dx <- imgradient(boat,"x") # extract gradient wrt x 
    dy <- imgradient(boat,"y") # extract gradient wrt y 
    grad.mag <- sqrt(dx^2+dy^2) # norm of gradient as estimation of edge 
    edge_boat_pix = grad.mag[, , , 1] # extracting pixels 
    
    boat.array[, , i] = edge_boat_pix
    
  }
 
 return(boat.array)
}


gondola_edge_pics = get_edge_pic_array('gondola/', gondola.filenames)
sailboat_edge_pics = get_edge_pic_array('sailboat/', sailboat.filenames)
cruise_edge_pics = get_edge_pic_array('cruise ship/', cruiseship.filenames)

boats <- matrix(NA, nrow = 600, ncol = 1+(115*345))
boats[,1] <- rep(c(1,2,3), each = 200)
# 1, 2, 3 is gondola, sailboat, cruise

for (i in 1:200){
  melt.array <- melt(gondola_edge_pics[,,i])[,3]
  
  for (j in 2:ncol(boats)){
    boats[i,j] <- melt.array[j-1]
  }
}

for (i in 201:400){
  melt.array <- melt(sailboat_edge_pics[,,i-200])[,3]
  
  for (j in 2:ncol(boats)){
    boats[i,j] <- melt.array[j-1]
  }
}

for (i in 401:600){
  melt.array <- melt(cruise_edge_pics[,,i-400])[,3]
  
  for (j in 2:ncol(boats)){
    boats[i,j] <- melt.array[j-1]
  }
}

# data frame of image and pixels row-wise.
boats <- as.data.frame(boats)

colnames(boats)[1] <- c("type")

boats$type <- ifelse(boats$type == 1, "gondola", 
                     ifelse(boats$type == 2, "sailboat", "cruise"))

#write_csv(boats, 'boats_edge_pixels.csv')

### reading in edge pixels back in.

boat_edges = read_csv('boats_edge_pixels.csv')
boats = boat_edges
boats$type = ifelse(boats$type == 'gondola', 1, ifelse(boats$type == 'sailboat', 2, 3))
boats$type = as.factor(boats$type)
levels(boats$type) = c('gondola', 'sailboat', 'cruise')
head(boats$type)

### reading in PCs from Otsu's method 
otsu = read_csv('otsu_pca.csv')
boats = otsu
boats = boats[, -1]
boats$type = ifelse(boats$type == 'gondola', 1, ifelse(boats$type == 'sailboat', 2, 3))
boats$type = as.factor(boats$type)
levels(boats$type) = c('gondola', 'sailboat', 'cruise')
head(boats$type)
names(boats)[1] = 'class'


#### PCA: converting pixels to PC loadings #### 

#Remove class labels prior to PCA
boats_labels = boats$type
boats_pixels = boats %>% select(-type)
pca.out = prcomp(boats_pixels, scale = T )

#Add boat type class labels back as "class"
pca.result = data.frame(class = boats_labels, pca.out$x[,1:40])

# write_csv(pca.result, 'edge_pca.csv')

#### Decision Trees: Model building/tuning !  #### 
library(tree)
library(randomForest)
library(caret)
library(e1071)
library(mlr)
library(xgboost)
library(parallel)
library(parallelMap) 


# Separate into 80% train, 20% validate

# PCs
set.seed(2)
train_ids <- sample((1:nrow(boats)), size = floor(.80*nrow(boats)))
train = pca.result[train_ids,]
test = pca.result[-train_ids,]
table(train$class)

# Pixels only 
set.seed(2)
train_ids <- sample((1:nrow(boats)), size = floor(.80*nrow(boats)))
train = boats[train_ids,]
test = boats[-train_ids,]
table(train$type)

# Otsu's PCs  
set.seed(2)
train_ids <- sample((1:nrow(boats)), size = floor(.80*nrow(boats)))
train = boats[train_ids,] 
test = boats[-train_ids,] 
table(train$class)

###
set.seed(2)
sub_train_ids = sample(1:nrow(train), size = floor(0.8*nrow(train)))
sub_train = train[sub_train_ids, ]
validate = train[-sub_train_ids, ]

## Basic decision tree 
tree1 = tree(class~., data=sub_train)
summary(tree1)
plot(tree1)
text(tree1, pretty = 0)

tree.pred = predict(tree1, validate, type="class")

with(validate, table('predictions' = tree.pred, 'actual' = class))
(16+21+19)/nrow(validate) # PC-loadings 
(12+22+10)/nrow(validate) # pixels only 
(17+8+10)/nrow(validate) # otsu


# pruning 
set.seed(2)
prune_tree1 = cv.tree(tree1, FUN = prune.misclass, K = 5) # default is 5-fold cross validation 
plot(prune_tree1) # choose 20 for PCs, 3 for pixels only, 8 for otsu
pruned = prune.misclass(tree1, best = 8)
plot(pruned)
text(pruned, pretty = 0)
tree.pred = predict(pruned, validate, type="class")

with(validate, table('predictions' = tree.pred, 'actual' = class))
(16+24+19)/nrow(validate)
(13+17+9)/nrow(validate)
(21+2+16)/nrow(validate)
### Random Forest 

# baseline 
rf = randomForest(class~., data = sub_train, ntree = 500)
rf

# tuning parameters for mtry and num trees 
# for MTry and Num Trees 
control <- trainControl(method="oob", number=5,search="grid")
tunegrid <- expand.grid(.mtry=c(1:(ncol(sub_train)-1)))
modellist <- list()
for (ntree in c(100, 250, 500, 750, 1000)) {
  set.seed(2)
  fit <- caret::train(class~., data=sub_train, method="rf", 
                      metric='Accuracy', tuneGrid=tunegrid, trControl=control, ntree=ntree)
  key <- toString(ntree)
  modellist[[key]] <- fit
}

# compare results
avg = c()
std = c()
med = c()
max_acc = c()
best_mtry = c()
for (i in 1:length(modellist)) {
  avg[i] = mean(modellist[[i]]$results$Accuracy)
  std[i] = sd(modellist[[i]]$results$Accuracy)
  med[i] = median(modellist[[i]]$results$Accuracy)
  max_acc[i] = max(modellist[[i]]$results$Accuracy)
  best_mtry[i] = modellist[[i]]$results[which.max(modellist[[i]]$results$Accuracy),'mtry']
}

result = cbind(avg, std, med, max_acc, best_mtry, 
               'ntree' = c(100, 250, 500, 750, 1000))


grid.arrange(ggplot(result %>% as.data.frame(), aes(ntree, max_acc))+geom_line(), 
             ggplot(result %>% as.data.frame(), aes(best_mtry, max_acc))+geom_line())


# choose mtry = 5, ntree = 750 (PCs)
# choose mtry = 12, ntree = 750 (pixels)
# choose mtry = 11, ntree = 750 (otsu)

rf_final = randomForest(class~., data = sub_train, ntree = 750, mtry = 11)
rf_final

preds = predict(rf_final, validate)
sum(preds == validate$class) / nrow(validate)

### XGBoost 

# converting class labels to numeric as per tutorial
sub_train_boost = sub_train
sub_train_boost$class = as.numeric(sub_train_boost$class)
validate_boost = validate
validate_boost$class = as.numeric(validate$class)

# converting train and validate sets to matrix as per tutorial 
sub_train_boost = as.matrix(sub_train_boost)
validate_boost = as.matrix(sub_train_boost)

train_class = sub_train_boost[, 1]
test_class = validate_boost[, 1]
train_class <- as.numeric(train_class)-1
test_class <- as.numeric(test_class)-1
sub_train_boost = sub_train_boost[, -1]
validate_boost = validate_boost[, -1]


dtrain <- xgb.DMatrix(data = sub_train_boost,label = train_class) 
dtest <- xgb.DMatrix(data = validate_boost,label=test_class)

# using default parameters first as a baseline 
params <- list(booster = "gbtree", objective = "multi:softmax", num_class = 3, 
               eta=0.3, gamma=0, max_depth=6, min_child_weight=1, 
               subsample=1, colsample_bytree=1)

xgbcv <- xgb.cv( params = params, data = dtrain, nrounds = 100, 
                 nfold = 5, showsd = T, stratified = T, print_every_n = 10, 
                 early_stop_round = 20, maximize = F)

1-min(xgbcv$evaluation_log$test_merror_mean) # baseline classification rate 

ggplot(xgbcv$evaluation_log, aes(iter, test_merror_mean))+geom_line()+xlab('NumTrees')+
  geom_vline(aes(xintercept = which.min(xgbcv$evaluation_log$test_merror_mean)), col = 'red', linetype = 'dashed')

# choose nrounds = 17 (PCs)
# nrounds = 39 for pixels 
# nrounds = 6 (otsu)
opt_nrounds = which.min(xgbcv$evaluation_log$test_merror_mean)

# tuning parameters 

#create tasks
traintask <- makeClassifTask (data = sub_train,target = "class")
testtask <- makeClassifTask (data = validate,target = "class")

#create learner
lrn <- makeLearner("classif.xgboost", predict.type = "response")
lrn$par.vals <- list(objective = "multi:softmax", num_class = 3, eval_metric="mlogloss", 
                     nrounds = opt_nrounds)

#set parameter space
params <- makeParamSet(makeDiscreteParam("booster",values = "gbtree"), 
                       makeIntegerParam("max_depth",lower = 3L,upper = 10L), 
                       makeNumericParam("min_child_weight",lower = 1L,upper = 10L), 
                       makeNumericParam("eta",lower = 0.001,upper = .1), 
                       makeNumericParam("colsample_bytree",lower = 0.5,upper = 1))

#set resampling strategy
rdesc <- makeResampleDesc("CV",stratify = T,iters=5L)

#search strategy
ctrl <- makeTuneControlRandom(maxit = 10L)

#set parallel backend

parallelStartSocket(cpus = detectCores())

#parameter tuning
mytune <- tuneParams(learner = lrn, task = traintask, 
                     resampling = rdesc, measures = acc, par.set = params, 
                     control = ctrl, show.info = T)

#set hyperparameters
lrn_tune <- setHyperPars(lrn,par.vals = mytune$x)

#train model
xgmodel <- train(learner = lrn_tune,task = traintask)


#predict model
xgpred <- predict(xgmodel,testtask)

confusionMatrix(xgpred$data$response,xgpred$data$truth)

####### Decision Trees: TESTING MODEL USING TUNING PARAMETERS FOUND IN MODEL BUILDING ####### 

### Basic Decision Tree

set.seed(2)
tree_final = tree(class~., data=train)
summary(tree_final)
plot(tree_final)
text(tree_final, pretty = 0)

tree.pred = predict(tree_final, test, type="class")

with(test, table('predictions' = tree.pred, 'actual' = class))
(26+21+23)/nrow(test) # PCs
(11+12+26)/nrow(test) # pixels 
(10+21+24)/nrow(test) #otsu

### Decision Tree with pruning, nodes = 20 (PCs)
### Decision Tree with pruning, nodes = 3 (pixels)
### Decision Tree with pruning, nodes = 8 (otsu)
pruned = prune.misclass(tree_final, best = 8)
plot(pruned)
text(pruned, pretty = 0)
tree.pred = predict(pruned, test, type="class")

with(test, table('predictions' = tree.pred, 'actual' = class))
(25+21+26)/nrow(test) # slightly worsened classification rate (PC)
(20+17+18)/nrow(test) # (pixels)
(13+9+30)/nrow(test) # otsu
### Random Forest: mtry = 5, ntree = 750
### Random Forest: mtry = 12, ntree = 750 (pixels)
### Random Forest: mtry = 11, ntree = 750 (otsu)

rf_final = randomForest(class~., data = train, mtry = 11, ntree = 750)
rf_final

preds = predict(rf_final, test)
sum(preds == test$class) / nrow(test)

### XGBoost: ntrees = 17, learning rate = 0.06958427, num split = 6 (pcs)
### XGBoost: ntrees = 39, learning rate = 0.0442338, num split = 8
### XGBoost: ntrees = 6, learning rate = 0..0938, num split = 6

# converting train and validate sets to matrix as per tutorial 
train_boost = train
train_boost$class = as.numeric(train_boost$class)

test_boost = test
test_boost$class = as.numeric(test_boost$class)

train_boost = as.matrix(train_boost)
test_boost = as.matrix(test_boost)



train_class = train_boost[, 1]
test_class = test_boost[, 1]
train_class <- as.numeric(train_class)-1
test_class <- as.numeric(test_class)-1
train_boost = train_boost[, -1]
test_boost = test_boost[, -1]


dtrain <- xgb.DMatrix(data = train_boost,label = train_class) 
dtest <- xgb.DMatrix(data = test_boost,label=test_class)

# saving tuning parameters for PCs
tuning_parameters_pc = mytune$x
tuning_parameters_otsu = mytune$x

params <- list(booster = "gbtree", objective = "multi:softmax", num_class = 3, eta= 0.09383885, 
               gamma=0, max_depth=7, min_child_weight=  1.994686,
               subsample=1, colsample_bytree=  0.749095)

xgb1 <- xgb.train (params = params, data = dtrain, nrounds = opt_nrounds, 
                   watchlist = list(val=dtest,train=dtrain), print_every_n = 10, 
                   early_stop_round = 10, maximize = F , eval_metric = "mlogloss")
#model prediction
xgbpred <- predict (xgb1,dtest)
confmatrix = table('preds' = xgbpred, 'actual' = test_class)
confmatrix
(25+23+33)/nrow(test) # PCs (best)
(22+32+23)/nrow(test) # adjusting other hyperparameters to address imbalance in misclassification
(17+19+21)/nrow(test) # otsu






####### Applying edge detection to other models ####### 
