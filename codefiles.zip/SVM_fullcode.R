####### DATA PREP SCRIPT ##### 

###### THIS CODE IS FOR GENERATING THE CSVS FOR THE BLUE PIXELS #######

### Required packages
library(tidyverse)
library(EBImage)
library(jpeg)
library(reshape2)

########### Extracting images for gondola, sailboat, and cruiseship (Image --> resize --> pixels) #############

gondola <- read.csv("gondola_200_blue.csv")
sailboat <- read.csv("sailboat_200_blue.csv")
cruise <- read.csv("cruise_200_blue.csv")


####### USING CODE FROM CSV TO CREATE PC-LOADINGS ############### 
data <- rbind(gondola, sailboat, cruise)

boats_pixels <- data

# Remove class labels prior to PCA
boats_labels <- boats_pixels$type
boats_pixels <- boats_pixels %>% select(-type)
pca.out <- prcomp( boats_pixels, scale = T )

# Add boat type class labels back as "class"
pca.result <- data.frame(class = boats_labels, pca.out$x[,1:40])

# Separate into 80% train, 20% validate
set.seed(2)
train_ids <- sample((1:600), size = floor(.80*600))
train <- pca.result[train_ids,]
test <- pca.result[-train_ids,]

# ---SVMs-------------------------------------

# Split train dataset into train and validate sets
train_validate_ids <- sample((1:480), size = floor(.60*480))

validate <- train[-train_validate_ids,]
train <- train[train_validate_ids,]

# Create dataframe for training error for SVM with linear kernel
# Varying cost parameter from 1 to 100

linear_svm_errors <- data.frame(matrix(c(1:100, rep(0, 100)), 
                                       nrow = 100, ncol = 2))

colnames(linear_svm_errors) <- c("cost", "errors")

# Run SVM with cost for each value between 1 and 100 and predict on validate set
# Compare predicted and actual class labels, update dataframe 
# Upon finishing, loop will have the error for each cost value

for (i in 1:100){
  
  fit <- svm(class~., data = train, scale = F, kernel = "linear", cost = i)
  
  pred <- predict(fit, validate)
  
  correct <- table(validate$class, pred) %>% diag() %>% sum()
  
  error <- 1 - correct/nrow(validate)
  
  linear_svm_errors$errors[i] <- error
  
  print(i)
}

# Find best cost value for linear kernel and run on test set

min(linear_svm_errors$errors)

opt_cost <- which.min(linear_svm_errors$errors)

svm_lin_opt <- svm(class~., data = train, scale = F, kernel = "linear", cost = opt_cost)

svm_lin_opt_pred <- predict(svm_lin_opt, test)

correct <- table(test$class, svm_lin_opt_pred) %>% 
  diag() %>% 
  sum()

svm_lin_opt_error <- error <- 1 - correct/nrow(test)

# Poly ---------------------------------------

# Create dataframe for training error for SVM with linear kernel
# Varying degree and cost parameters

poly_svm_errors <- data.frame(matrix(c(rep(1:10, each = 50), 
                                       rep(seq(from = 1, to = 99, by = 2), 10),
                                       rep(0, 500)),
                                     nrow = 500, ncol = 3))

colnames(poly_svm_errors) <- c("degree", "cost", "errors")

# Run SVM with cost for each degree and cost value and predict on validate set
# Compare predicted and actual class labels, update dataframe 
# Upon finishing, loop will have the error for each cost value

for (i in 1:500){
  
  fit <- svm(class~., data = train, scale = F, 
             kernel = "polynomial", 
             degree = poly_svm_errors$degree[i], 
             cost = poly_svm_errors$cost[i])
  
  pred <- predict(fit, validate)
  
  correct <- table(validate$class, pred) %>% diag() %>% sum()
  
  poly_svm_errors$errors[i] <- 1 - correct/nrow(validate)
  
  print(i)
  
}

# Find best cost value for polynomial kernel and run on test set

min(poly_svm_errors$errors)

opt_index <- which.min(poly_svm_errors$errors)

opt_degree <- poly_svm_errors$degree[opt_index]
opt_cost <- poly_svm_errors$cost[opt_index]

svm_poly_opt <- svm(class~., data = train, scale = F, 
                    kernel = "polynomial", 
                    cost = opt_cost, 
                    degree = opt_degree)

svm_poly_opt_pred <- predict(svm_poly_opt, test)

correct <- table(test$class, svm_poly_opt_pred) %>% 
  diag() %>% 
  sum()

svm_poly_opt_error <- 1 - correct/nrow(test)

svm_poly_opt_error

### Otsu's Method ----------------------------------------------------------

rotate <- function(x) t(apply(x, 2, rev))

otsu_df <- data.frame(matrix(NA, nrow = 600, ncol = 39675))

for (i in 1:600){
  
  image <- array(as.numeric(unlist(data[i, 2:39676])), 
                 dim = c(115, 345, 1))
  
  image_otsu <- image > otsu(image)
  
  image_otsu <- rotate(rotate(rotate(image_otsu)))
  
  otsu_df[i, ] <- as.numeric(image_otsu)
  
  print(i)
  
}

boats_pixels <- otsu_df

pca.out <- prcomp(boats_pixels, scale = T )

boats_labels <- c(rep("gondola", 200), 
                  rep("sailboat", 200), 
                  rep("cruise", 200))

pca.result <- data.frame(type = boats_labels, 
                         pca.out$x[, 1:40])

# Separate into 80% train, 20% validate

set.seed(2)
train_ids <- sample((1:600), size = floor(.80*600))
train <- pca.result[train_ids,]
test <- pca.result[-train_ids,]

## SVMs -----------------------------------------

# Split train dataset into train and validate sets
train_validate_ids <- sample((1:480), size = floor(.60*480))

validate <- train[-train_validate_ids,]
train <- train[train_validate_ids,]

# Create dataframe for training error for SVM with linear kernel
# Varying cost parameter from 1 to 100

linear_svm_errors_otsu <- data.frame(matrix(c(1:100, rep(0, 100)), 
                                            nrow = 100, ncol = 2))

colnames(linear_svm_errors_otsu) <- c("cost", "errors")

# Run SVM with cost for each value between 1 and 100 and predict on validate set
# Compare predicted and actual class labels, update dataframe 
# Upon finishing, loop will have the error for each cost value

for (i in 1:100){
  
  fit <- svm(type~., data = train, scale = F, kernel = "linear", cost = i)
  
  pred <- predict(fit, validate)
  
  correct <- table(validate$type, pred) %>% diag() %>% sum()
  
  error <- 1 - correct/nrow(validate)
  
  linear_svm_errors_otsu$errors[i] <- error
  
  print(i)
}

min(linear_svm_errors_otsu$errors)

opt_cost <- which.min(linear_svm_errors_otsu$errors)

full.train <- rbind(train, validate)

svm_lin_opt_otsu <- svm(type~., data = full.train, scale = F, 
                        kernel = "linear", cost = opt_cost)

svm_lin_opt_pred_otsu <- predict(svm_lin_opt_otsu, test)

correct_lin_otsu <- table(test$type, svm_lin_opt_pred_otsu) %>% 
  diag() %>% 
  sum()

(svm_lin_opt_error_otsu <- 1 - correct_lin_otsu/nrow(test))

# Poly ---------------------------------------

# Create dataframe for training error for SVM with linear kernel
# Varying degree and cost parameters

poly_svm_errors_otsu <- data.frame(matrix(c(rep(1:10, each = 50), 
                                            rep(seq(from = 1, to = 99, by = 2), 10),
                                            rep(0, 500)),
                                          nrow = 500, ncol = 3))

colnames(poly_svm_errors_otsu) <- c("degree", "cost", "errors")

# Run SVM with cost for each degree and cost value and predict on validate set
# Compare predicted and actual class labels, update dataframe 
# Upon finishing, loop will have the error for each cost value

for (i in 1:500){
  
  fit <- svm(type~., data = train, scale = F, 
             kernel = "polynomial", 
             degree = poly_svm_errors_otsu$degree[i], 
             cost = poly_svm_errors_otsu$cost[i])
  
  pred <- predict(fit, validate)
  
  correct <- table(validate$type, pred) %>% diag() %>% sum()
  
  poly_svm_errors_otsu$errors[i] <- 1 - correct/nrow(validate)
  
  print(i)
  
}

# Find best cost value for polynomial kernel and run on test set

min(poly_svm_errors_otsu$errors)

opt_index <- which.min(poly_svm_errors_otsu$errors)

opt_degree <- poly_svm_errors_otsu$degree[opt_index]
opt_cost <- poly_svm_errors_otsu$cost[opt_index]

svm_poly_opt_otsu <- svm(type~., data = full.train, scale = F, 
                         kernel = "polynomial", 
                         cost = opt_cost, 
                         degree = opt_degree)

svm_poly_opt_pred_otsu <- predict(svm_poly_opt_otsu, test)

correct_poly_otsu <- table(test$type, svm_poly_opt_pred_otsu) %>% 
  diag() %>% 
  sum()

(svm_poly_opt_error_otsu <- 1 - correct_poly_otsu/nrow(test))




####### Edge Detection, SVM Script #####-----------------------------------

### Required packages----------------------------
library(tidyverse)
library(EBImage)
library(jpeg)
library(reshape2)

data <- read.csv("boats_edge_pixels.csv")

boats_pixels <- data

# Remove class labels prior to PCA
boats_labels <- boats_pixels$type
boats_pixels <- boats_pixels %>% select(-type)
pca.out <- prcomp( boats_pixels, scale = T )

# Add boat type class labels back as "class"
pca.result <- data.frame(class = boats_labels, pca.out$x[,1:40])

# Separate into 80% train, 20% validate
set.seed(2)
train_ids <- sample((1:600), size = floor(.80*600))
train <- pca.result[train_ids,]
test <- pca.result[-train_ids,]

# ---SVMs-------------------------------------

# Split train dataset into train and validate sets
train_validate_ids <- sample((1:480), size = floor(.60*480))

validate <- train[-train_validate_ids,]
train <- train[train_validate_ids,]

# Create dataframe for training error for SVM with linear kernel
# Varying cost parameter from 1 to 100

linear_svm_errors <- data.frame(matrix(c(1:100, rep(0, 100)), 
                                       nrow = 100, ncol = 2))

colnames(linear_svm_errors) <- c("cost", "errors")

# Run SVM with cost for each value between 1 and 100 and predict on validate set
# Compare predicted and actual class labels, update dataframe 
# Upon finishing, loop will have the error for each cost value

for (i in 1:100){
  
  fit <- svm(class~., data = train, scale = F, kernel = "linear", cost = i)
  
  pred <- predict(fit, validate)
  
  correct <- table(validate$class, pred) %>% diag() %>% sum()
  
  error <- 1 - correct/nrow(validate)
  
  linear_svm_errors$errors[i] <- error
  
  print(i)
}

# Find best cost value for linear kernel and run on test set

min(linear_svm_errors$errors)

(opt_cost <- which.min(linear_svm_errors$errors))

svm_lin_opt <- svm(class~., data = train, scale = F, kernel = "linear", cost = opt_cost)

svm_lin_opt_pred <- predict(svm_lin_opt, test)

correct <- table(test$class, svm_lin_opt_pred) %>% 
  diag() %>% 
  sum()

(svm_lin_opt_error <- error <- 1 - correct/nrow(test))


# Poly ---------------------------------------

# Create dataframe for training error for SVM with linear kernel
# Varying degree and cost parameters

poly_svm_errors <- data.frame(matrix(c(rep(1:10, each = 50), 
                                       rep(seq(from = 1, to = 99, by = 2), 10),
                                       rep(0, 500)),
                                     nrow = 500, ncol = 3))

colnames(poly_svm_errors) <- c("degree", "cost", "errors")

# Run SVM with cost for each degree and cost value and predict on validate set
# Compare predicted and actual class labels, update dataframe 
# Upon finishing, loop will have the error for each cost value

for (i in 1:500){
  
  fit <- svm(class~., data = train, scale = F, 
             kernel = "polynomial", 
             degree = poly_svm_errors$degree[i], 
             cost = poly_svm_errors$cost[i])
  
  pred <- predict(fit, validate)
  
  correct <- table(validate$class, pred) %>% diag() %>% sum()
  
  poly_svm_errors$errors[i] <- 1 - correct/nrow(validate)
  
  print(i)
  
}

# Find best cost value for polynomial kernel and run on test set

min(poly_svm_errors$errors)

opt_index <- which.min(poly_svm_errors$errors)

opt_degree <- poly_svm_errors$degree[opt_index]
opt_cost_poly <- poly_svm_errors$cost[opt_index]

svm_poly_opt <- svm(class~., data = train, scale = F, 
                    kernel = "polynomial", 
                    cost = opt_cost_poly, 
                    degree = opt_degree)

svm_poly_opt_pred <- predict(svm_poly_opt, test)

correct <- table(test$class, svm_poly_opt_pred) %>% 
  diag() %>% 
  sum()

svm_poly_opt_error <- 1 - correct/nrow(test)

svm_poly_opt_error


### Otsu's Method Dataset Creation ---------------------------------------------------------

gondola <- fread("gondola_200_blue.csv", header = T, sep = ",")
gondola <- as.data.frame(gondola)

sailboat <- fread("sailboat_200_blue.csv", header = T, sep = ",")
sailboat <- as.data.frame(sailboat)

cruise <- fread("cruise_200_blue.csv", header = T, sep = ",")
cruise <- as.data.frame(cruise)

data <- data.frame(matrix(NA, nrow = 600, ncol = 39676))

for (i in 1:200){ 
  data[i, ] <- gondola[i, ] 
}

for (i in 201:400){ 
  data[i, ] <- sailboat[i-200, ] 
}

for (i in 401:600){ 
  data[i, ] <- cruise[i-400, ] 
}

### Otsu's Method --------------------

rotate <- function(x) t(apply(x, 2, rev))

otsu_df <- data.frame(matrix(NA, nrow = 600, ncol = 39675))

for (i in 1:600){
  
  image <- array(as.numeric(unlist(data[i, 2:39676])), 
                 dim = c(115, 345, 1))
  
  image_otsu <- image > otsu(image)
  
  image_otsu <- rotate(rotate(rotate(image_otsu)))
  
  otsu_df[i, ] <- as.numeric(image_otsu)
  
  print(i)
  
}

boats_pixels <- otsu_df

pca.out <- prcomp(boats_pixels, scale = T )

boats_labels <- c(rep("gondola", 200), 
                  rep("sailboat", 200), 
                  rep("cruise", 200))

pca.result <- data.frame(type = boats_labels, 
                         pca.out$x[, 1:20])

# Separate into 80% train, 20% validate

set.seed(2)
train_ids <- sample((1:600), size = floor(.80*600))
train <- pca.result[train_ids,]
test <- pca.result[-train_ids,]

## SVMs -----------------------------------------

# Split train dataset into train and validate sets
train_validate_ids <- sample((1:480), size = floor(.60*480))

validate <- train[-train_validate_ids,]
train <- train[train_validate_ids,]

# Create dataframe for training error for SVM with linear kernel
# Varying cost parameter from 1 to 100

linear_svm_errors <- data.frame(matrix(c(1:100, rep(0, 100)), 
                                       nrow = 100, ncol = 2))

colnames(linear_svm_errors) <- c("cost", "errors")

# Run SVM with cost for each value between 1 and 100 and predict on validate set
# Compare predicted and actual class labels, update dataframe 
# Upon finishing, loop will have the error for each cost value

for (i in 1:100){
  
  fit <- svm(type~., data = train, scale = F, kernel = "linear", cost = i)
  
  pred <- predict(fit, validate)
  
  correct <- table(validate$type, pred) %>% diag() %>% sum()
  
  error <- 1 - correct/nrow(validate)
  
  linear_svm_errors$errors[i] <- error
  
  print(i)
}

min(linear_svm_errors$errors)

opt_cost <- which.min(linear_svm_errors$errors)

svm_lin_opt <- svm(type~., data = train, scale = F, kernel = "linear", cost = opt_cost)

svm_lin_opt_pred <- predict(svm_lin_opt, test)

correct <- table(test$type, svm_lin_opt_pred) %>% 
  diag() %>% 
  sum()

svm_lin_opt_error <- error <- 1 - correct/nrow(test)

# Poly ---------------------------------------

# Create dataframe for training error for SVM with linear kernel
# Varying degree and cost parameters

poly_svm_errors <- data.frame(matrix(c(rep(1:10, each = 50), 
                                       rep(seq(from = 1, to = 99, by = 2), 10),
                                       rep(0, 500)),
                                     nrow = 500, ncol = 3))

colnames(poly_svm_errors) <- c("degree", "cost", "errors")

# Run SVM with cost for each degree and cost value and predict on validate set
# Compare predicted and actual class labels, update dataframe 
# Upon finishing, loop will have the error for each cost value

for (i in 1:500){
  
  fit <- svm(type~., data = train, scale = F, 
             kernel = "polynomial", 
             degree = poly_svm_errors$degree[i], 
             cost = poly_svm_errors$cost[i])
  
  pred <- predict(fit, validate)
  
  correct <- table(validate$type, pred) %>% diag() %>% sum()
  
  poly_svm_errors$errors[i] <- 1 - correct/nrow(validate)
  
  print(i)
  
}

# Find best cost value for polynomial kernel and run on test set

min(poly_svm_errors$errors)

opt_index <- which.min(poly_svm_errors$errors)

opt_degree <- poly_svm_errors$degree[opt_index]
opt_cost <- poly_svm_errors$cost[opt_index]

svm_poly_opt <- svm(type~., data = train, scale = F, 
                    kernel = "polynomial", 
                    cost = opt_cost, 
                    degree = opt_degree)

svm_poly_opt_pred <- predict(svm_poly_opt, test)

correct <- table(test$type, svm_poly_opt_pred) %>% 
  diag() %>% 
  sum()

svm_poly_opt_error <- error <- 1 - correct/nrow(test)

svm_poly_opt_error


### Figuring out number of Principal Components to Retain --------------------

boats <- boats_pixels

components.vec <- numeric(nrow(boats))

for (i in 1:nrow(boats)){
  row <- boats[i, ] %>% as.numeric()
  row.mat <- matrix(row, 
                    nrow = 115, ncol = 345)
  pr.out <- prcomp(row.mat)
  pr.var <- pr.out$sdev^2
  pve <- pr.var / sum(pr.var)
  components.vec[i] <- min(which(cumsum(pve) > 0.9))
}

plot(density(components.vec))
mean(components.vec)
median(components.vec)