
##Code for generating blue pixel PC loadings
#Then running K-NN, LDA, and QDA

#This same code was run in a slightly modified format 
#for the alternative feature extraction methods Otsu's method,
#edge detection, and data augmentation, but since that code is only
#slightly different for those it is not included.


#setup
setwd("C:/Users/stule/OneDrive/Documents/Fourth Yr Academics/
      Spring 2019/STOR 565/Finalproject/boat-types-recognition")


library(dplyr)
library(readr)

boats_pixels = read_csv('boats_pixels_blue.csv')

### PCA ###
set.seed(2)
#Remove class labels prior to PCA
boats_labels = boats_pixels$type
boats_pixels = boats_pixels %>% select(-type)
pca.out = prcomp(boats_pixels, scale = T )

#Add boat type class labels back as "class"
#Keep 40 PC loadings
pca.result = data.frame(class = boats_labels, pca.out$x[,1:40])

#Separate into 80% train, 20% validate
train_ids <- sample((1:nrow(pca.result)), size = floor(.80*nrow(pca.result)))
train = pca.result[train_ids,]
validate = pca.result[-train_ids,]

### KNN ###
library(MASS) 
library(mvtnorm) 
library(class)
library(dplyr)

#Select best k from k = 1 to 100
five_fold_cv <- function(data) {
  set.seed(2)
  
  class_errors <- data.frame("k" = NA, "average error" = NA)
  
  random_data <- data[sample(nrow(data)),]
  splitted <- split(random_data, c(1,2,3,4,5))
  
  for (i in 1:100) {
    #let k range from 1 to 100
    total_error <- 0
    
    for (j in 5:1) {
      test <- splitted[[j]]
      train <- random_data %>% anti_join(test)
      train_predictors <- dplyr::select(train, -matches("class"))
      test_predictors <- dplyr::select(test, -matches("class"))
      knn_result <- knn(train_predictors, test_predictors, cl = train$class, k = i)
      
      for (k in 1: length(knn_result)) {
        if (knn_result[k] != test$class[k]) {
          total_error <- total_error + 1
        }
      }
    }
    
    class_errors[i, ] = c(i, total_error/5)
  }
  return(class_errors)
} 

(result <- five_fold_cv(train))
best <- result[which.min(result[,2]),1]
#Best K = 17 


#execute knn and compute the error rate
knn_func <- function() {
  
  id_data <- mutate(train, id = row.names(train)) 
  knn_train_predictors <- dplyr::select(train, -matches("class"))
  knn_test_predictors <- dplyr::select(validate, -matches("class"))
  
  knn_k <- knn(knn_train_predictors, knn_test_predictors, 
               cl = train$class, k = best)
  
  return((sum(knn_k != validate$class))/nrow(validate))
}

knn_func()
#returns a 46.67% error rate
#53.33% accuracy



##LDA and QDA##

#verify normality, test first 4 PC's
par(mfrow = c(2,2))
for (i in 2:5) {
     hist(pca.result[,i], main = '', xlab = paste0('PC',i-1))
}
#Appears valid to continue with LDA and QDA


### LDA ###

#assumption of normality of PC scores 
#across each PC component is satisfied

lda_mod <- lda(class~., data = train)
lda_pred <- predict(lda_mod, validate, type = "response")$class
lda_error_rate <- (sum(lda_pred != validate$class))/nrow(validate)
lda_error_rate
#56.67% error rate
#43.33% accuracy

### QDA ###

#assumption of normality of PC scores 
#across each PC component is satisfied

qda_mod <- qda(class~., data = train)
qda_pred <- predict(qda_mod, validate, type = "response")$class
qda_error_rate <- (sum(qda_pred != validate$class))/nrow(validate)
qda_error_rate
#57.5% error rate
#42.5% accuracy

